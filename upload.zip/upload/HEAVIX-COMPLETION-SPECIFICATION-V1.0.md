# HEAVIX — سند جامع اصلاح، توسعه و تکمیل پروژه
## HEAVIX COMPLETION / HARDENING / DEVELOPMENT MASTER SPECIFICATION — V1.0
### مبنای بررسی: آرشیو پروژه ارسالی در 2026-09-22
### هدف: تبدیل وضعیت فعلی کد به یک پلتفرم Marketplace صنعتی/معدنی Production-Ready

---

# 0. مقدمه و اصل حاکم

این سند بر مبنای **خود آرشیو پروژه ارسالی**، کد فعلی، Prisma schema، migration، package configuration، تست‌ها و اسناد موجود در `docs/` تنظیم شده است.

این سند جایگزین سند مادر پروژه نیست؛ بلکه **سند اجرایی تکمیل و رفع Gap** است و باید پس از تأیید به مرجع اجرای توسعه تبدیل شود.

اصل مهم:

> «هیچ قابلیت جدیدی صرفاً به‌خاطر وجود آن در سند یا Schema، تکمیل‌شده محسوب نمی‌شود. تکمیل فقط زمانی پذیرفته است که Code + DB + API + UI + Security + Test + Documentation + Monitoring همگی هم‌راستا و قابل اثبات باشند.»

بنابراین وضعیت هر قابلیت باید یکی از این موارد باشد:

- `IMPLEMENTED_AND_VERIFIED`
- `IMPLEMENTED_NEEDS_HARDENING`
- `SCHEMA_ONLY`
- `API_ONLY`
- `UI_ONLY`
- `PARTIAL`
- `PLANNED`
- `BLOCKED`

---

# 1. وضعیت واقعی نسخه بررسی‌شده

در آرشیو فعلی، نسبت به Audit مورخ 2026-09-20 پیشرفت قابل توجهی انجام شده است.

## 1.1 مواردی که اکنون در Schema وجود دارند

Schema فعلی شامل حدود 95 مدل است و حوزه‌های زیر را پوشش می‌دهد:

- Brand / BrandAlias / BrandFamily
- Category / Taxonomy
- Dynamic Attributes
- Country / Province / City
- ProductModel / Generation
- Product
- Machine
- Part
- Attachment
- CompatibilityEdge
- Listing
- BuyRequest
- RFQ / RFQQuote
- Auction / AuctionBid
- ListingOffer
- Company / CompanyBranch / CompanyVerification / CompanyDocument
- DealRoom / DealMessage
- PriceRecord
- SearchIndex
- AI Gateway / AI Budget / AI Task Policy
- AIAgent
- Opportunity / DemandSignal
- Payment
- Procurement / ProcurementQuote
- SEO Metadata
- User / Session / AdminSession
- Role / Permission / RolePermission / UserRole
- AuditLog
- Notifications / Favorites / SavedSearch / Follow
- MachinePassport
- Subscription / FoundingSeller
- Knowledge / Article

بنابراین بخشی از مواردی که در Audit قدیمی به‌عنوان «غایب در Schema» گزارش شده بودند، در نسخه فعلی **اضافه شده‌اند**.

## 1.2 مواردی که باید همچنان Verification شوند

وجود Model در Prisma به‌تنهایی کافی نیست. برای هر Domain باید این زنجیره تکمیل شود:

```text
Schema
→ Migration
→ Seed
→ Repository/Service
→ API
→ Admin UI
→ Public UI
→ Validation
→ Authorization
→ Audit
→ Tests
→ Monitoring
```

---

# 2. تصمیمات غیرقابل مذاکره

## 2.1 Database

### Production

`PostgreSQL`

### Local

می‌تواند PostgreSQL محلی باشد.

### Test

PostgreSQL تست یا SQLite فقط در صورتی که تفاوت رفتاری آن برای Domainهای مورد آزمایش قابل قبول و مستند باشد.

### ممنوع

استفاده از:

```text
prisma db push --accept-data-loss
```

در Production.

### الزام

تمام تغییرات Schema فقط از طریق Migration.

---

# 3. Migration و Database Governance

در آرشیو فعلی Migration پایه وجود دارد، اما مسیر باید به یک Migration Discipline واقعی تبدیل شود.

## اقدامات

- baseline migration تأیید شود.
- migration history با schema تطبیق داده شود.
- migration drift check اضافه شود.
- Production فقط `prisma migrate deploy`.
- CI باید migration validation داشته باشد.
- seedها idempotent باشند.
- destructive migration نیازمند approval باشد.
- backup قبل از migration حساس انجام شود.

## Acceptance

```text
prisma validate = PASS
migration status = CLEAN
schema drift = 0
seed repeatability = PASS
```

---

# 4. اصلاح package و Runtime

در package فعلی، Scriptهای Build/Start هنوز Unix/Bun-oriented هستند:

```text
cp -r
NODE_ENV=production ...
tee
bun ...
```

باید Runtime رسمی پروژه تعیین شود.

## تصمیم پیشنهادی

برای Production:

```text
Node.js
Next.js
PostgreSQL
Object Storage
Redis/Queue
```

Bun می‌تواند ابزار توسعه اختیاری باشد، اما نباید تنها مسیر اجرای Production باشد مگر اینکه عمداً به‌عنوان استاندارد رسمی انتخاب و تست شود.

## Scripts نهایی باید شامل

```text
dev
build
start
lint
typecheck
test
test:e2e
test:security
db:validate
db:migrate
db:migrate:deploy
db:seed
catalog:health
security:check
```

باشد.

---

# 5. Authentication — وضعیت هدف نهایی

نسخه فعلی دارای Session امن‌تر و User Session است، اما باید دو مسیر Auth کاملاً استاندارد شوند.

## 5.1 Admin

باید:

- DB-backed admin identity
- password hash
- cryptographically random session
- hashed session token
- expiration
- revocation
- session rotation
- Secure
- HttpOnly
- SameSite
- MFA
- login throttling
- audit

داشته باشد.

## 5.2 User

- password hash
- email verification
- mobile verification
- session expiry
- logout
- logout all sessions
- account lock
- password reset
- password change
- session revocation
- suspicious login detection

## 5.3 حذف کامل Legacy Authentication

پس از migration:

```text
User.role
```

نباید منبع نهایی authorization باشد.

منبع نهایی:

```text
User
→ UserRole
→ Role
→ RolePermission
→ Permission
```

باشد.

---

# 6. RBAC — اصلاح بحرانی

Schema RBAC وجود دارد و helperهای آن نیز وجود دارند.

اما بررسی آرشیو نشان می‌دهد تعداد زیادی از Routeهای `/api/admin/*` صرفاً Authentication را بررسی می‌کنند و به‌صورت مستقیم `requirePermission()` استفاده نمی‌کنند.

این یعنی:

> وجود RBAC در Schema و Helper کافی نیست؛ RBAC باید روی تمام مسیرهای حساس enforce شود.

## معماری نهایی

```text
Request
 ↓
Authentication
 ↓
Role/Permission
 ↓
Resource Ownership / Scope
 ↓
Validation
 ↓
Operation
 ↓
Audit
```

## Permissionهای پایه

```text
system.read
system.manage
security.read
security.manage

user.read
user.create
user.update
user.suspend
user.delete

company.read
company.verify
company.manage

taxonomy.read
taxonomy.create
taxonomy.update
taxonomy.delete
taxonomy.publish

brand.read
brand.create
brand.update
brand.verify
brand.publish

model.read
model.create
model.update
model.publish

product.read
product.create
product.update
product.publish

listing.read
listing.create
listing.update
listing.publish
listing.moderate
listing.delete

price.read
price.estimate
price.review
price.override

compare.read

request.read
request.match
rfq.create
rfq.manage
offer.create
offer.manage

auction.manage
dealroom.manage
inspection.manage
transport.manage

ai.read
ai.execute
ai.manage
ai.policy.manage
ai.budget.manage
ai.agent.manage

media.read
media.upload
media.moderate
media.delete

payment.read
payment.manage
refund.manage

audit.read
audit.export

jobs.read
jobs.run
jobs.retry

seo.manage
knowledge.manage
```

---

# 7. Admin API Security

تمام Routeهای `/api/admin/*` باید از Middleware/Guard مرکزی استفاده کنند.

هدف:

```text
requireAdminPermission("brand.update")
```

یا equivalent مرکزی.

نباید هر Route پیاده‌سازی Auth متفاوت داشته باشد.

## الزام

یک Guard مرکزی:

```text
requireAdmin()
requirePermission()
requireAnyPermission()
requireOwnership()
```

ایجاد و در تمام Admin APIها استفاده شود.

---

# 8. Audit Log

مدل AuditLog در Schema و helper موجود است.

اما باید Coverage کامل شود.

## هر عملیات حساس باید ثبت کند

```text
actor
actorType
action
entityType
entityId
before
after
IP
User-Agent
requestId
reason
timestamp
```

## عملیات اجباری

- login
- logout
- failed login
- role change
- permission change
- user suspension
- brand verification
- model publication
- listing publication
- listing rejection
- price override
- AI execution
- AI policy change
- AI budget change
- upload rejection
- payment status change
- refund
- auction bid
- RFQ award
- company verification
- document verification
- admin setting change

## Audit باید Append-only باشد

هیچ API عمومی برای:

```text
update AuditLog
delete AuditLog
```

وجود نداشته باشد.

---

# 9. Registration و Account Lifecycle

ثبت‌نام عمومی فقط باید User معمولی بسازد.

```text
PUBLIC REGISTER
→ BUYER / SELLER workflow
```

هرگز:

```text
ADMIN
```

از Public API ساخته نشود.

## Account Lifecycle

```text
PENDING
→ EMAIL_VERIFIED
→ ACTIVE
→ SUSPENDED
→ BLOCKED
→ DELETED/ANONYMIZED
```

قواعد هر انتقال باید مشخص و Audit شود.

---

# 10. Password و Verification

## Password

- bcrypt/Argon2id
- minimum length
- password strength
- breach-resistant policy
- never log password
- never return password
- reset token hashed
- reset token expiration

## Verification

Verification Code نباید plaintext در DB نگهداری شود.

ترجیحاً:

```text
hash(code)
expiresAt
usedAt
attemptCount
purpose
```

نگهداری شود.

---

# 11. Product Catalog — مرجع اصلی

معماری نهایی:

```text
Category
 ↓
Brand
 ↓
ProductModel
 ↓
Generation
 ↓
Product
 ↓
Machine / Part / Attachment
 ↓
Listing
```

## اصل

`Product` با `Listing` یکی نیست.

### Product

کالای canonical.

### Machine

نمونه فیزیکی مشخص.

### Listing

پیشنهاد بازار برای فروش/اجاره/درخواست/مزایده.

---

# 12. Machine Identity

Machine باید برای ماشین واقعی قابل استفاده باشد:

```text
Product
Serial
Year
Hours
Condition
Ownership
Location
Passport
Inspection
Media
Documents
```

## Machine Passport

باید تاریخچه‌ای داشته باشد:

```text
Purchase
Import
Inspection
Maintenance
Repair
Ownership Transfer
Listing
Sale
Archive
```

هر Event باید immutable/auditable باشد.

---

# 13. Parts و Attachments

Domain باید کامل شود:

```text
Part
Attachment
OEM Part
Aftermarket Part
Consumable
Kit
Assembly
```

و هرکدام Catalog مستقل داشته باشند.

---

# 14. Compatibility Graph

مدل CompatibilityEdge وجود دارد.

باید Rules نهایی:

```text
FITS
COMPATIBLE_WITH
REPLACES
UPGRADES
REQUIRES
OPTIONAL_FOR
NOT_COMPATIBLE
```

باشد.

هر رابطه:

```text
source
target
relation
confidence
sourceReference
verified
verifiedBy
verifiedAt
```

داشته باشد.

AI فقط می‌تواند رابطه را پیشنهاد کند؛ تأیید نهایی باید طبق Policy انجام شود.

---

# 15. Dynamic Attribute Engine

AttributeDefinition و CategoryAttribute وجود دارند.

نسخه نهایی باید شامل:

```text
Definition
Option
Unit
Validation
Visibility
Filterability
Searchability
SEO relevance
AI relevance
Provenance
```

باشد.

## Attribute Value

هر مقدار باید بتواند مشخص کند:

```text
value
unit
source
confidence
verifiedBy
verifiedAt
```

را.

## قانون

`AI_INFERENCE` هرگز معادل `ADMIN_VERIFIED` نیست.

---

# 16. Category Attribute Inheritance

برای جلوگیری از تکرار:

```text
Parent Category Attributes
↓
Child Category
↓
Override / Add / Remove
```

تعریف شود.

---

# 17. Canonical Location

Listing فعلی علاوه بر IDs هنوز legacy string fields دارد.

این گذار باید تکمیل شود.

Canonical:

```text
Country
→ Province
→ City
```

و در صورت نیاز:

```text
District
→ Industrial Zone
→ Exact Location
```

با privacy control.

## هدف

Search، SEO و Analytics فقط از Canonical IDs استفاده کنند.

---

# 18. Transaction Model

`TransactionType` وجود دارد.

باید همه Listingهای جدید فقط از:

```text
transactionTypeId
```

استفاده کنند.

Legacy `listingType` باید migration شود و سپس حذف گردد.

Transactionها:

```text
SALE
RENT
WANTED
QUOTE
AUCTION
SERVICE_REQUEST
```

---

# 19. Listing Lifecycle

State machine رسمی:

```text
DRAFT
→ PENDING_REVIEW
→ PUBLISHED
→ PAUSED
→ EXPIRED
→ SOLD
→ ARCHIVED
→ REJECTED
```

هیچ Route نباید بتواند وضعیت را آزادانه به هر String تبدیل کند.

تمام Transitionها باید Policy داشته باشند.

---

# 20. Seller / Company

یک Marketplace صنعتی به Company Domain قوی نیاز دارد.

```text
Company
├── Users
├── Branches
├── Documents
├── Verification
├── Listings
├── Requests
├── RFQ
├── Offers
├── Payments
└── Reputation
```

## Verification Levels

```text
UNVERIFIED
PHONE_VERIFIED
EMAIL_VERIFIED
BUSINESS_VERIFIED
DOCUMENT_VERIFIED
INSPECTED
TRUSTED
```

سطوح باید تعریف دقیق داشته باشند و صرفاً Badge ظاهری نباشند.

---

# 21. Search Engine

Search فعلی دارای normalization و SearchIndex است، اما باید Search را یک Domain مستقل در نظر گرفت.

## معماری نهایی

```text
Query
↓
Persian Normalization
↓
Intent Detection
↓
Entity Resolution
↓
Lexical Search
+
Structured Filters
+
Semantic Search
↓
Ranking
↓
Result
```

## Persian normalization

- ی/ي
- ک/ك
- ZWNJ
- whitespace
- Arabic digits / Persian digits
- transliteration
- aliases
- brand aliases
- model aliases
- technical abbreviations

---

# 22. Search Ranking

Ranking باید configurable باشد:

```text
Relevance
Data Quality
Freshness
Verification
Location
Price fit
Completeness
Seller quality
```

Ranking نباید بدون دلیل قابل مشاهده تغییر کند.

---

# 23. Price Intelligence

PriceRecord موجود است اما برای موتور کامل قیمت کافی نیست.

باید تکمیل شود:

```text
PriceObservation
PriceComparable
PriceAdjustment
PriceEstimate
PriceModelVersion
PriceReview
PriceOverride
```

## Price Estimate

خروجی:

```text
estimatedMin
estimatedMedian
estimatedMax
currency
confidence
sampleCount
observedAt
modelVersion
drivers
warnings
```

## قانون

قیمت Asking و Estimated جدا باشند.

AI حق ندارد بدون داده معتبر قیمت قطعی تولید کند.

---

# 24. Compare Engine

Compare باید:

- Model Compare
- Product Compare
- Listing Compare
- Machine Compare

را پشتیبانی کند.

حالت‌ها:

```text
ALL
DIFFERENCES_ONLY
PRICING
TECHNICAL
APPLICATION
CONDITION
```

## AI Compare

AI فقط بر اساس داده ساختاریافته و Sourceهای معتبر خلاصه تولید کند.

---

# 25. Request / Wanted

BuyRequest باید تبدیل به Demand Engine شود:

```text
Buyer Request
↓
Requirement Extraction
↓
Catalog Matching
↓
Seller Matching
↓
Notification
↓
Offer
```

---

# 26. RFQ و Procurement

RFQ و Procurement باید از Listing جدا بمانند.

```text
RFQ
→ Quotes
→ Compare
→ Negotiation
→ Award
→ Deal
```

برای B2B باید:

- deadline
- terms
- quantity
- specifications
- delivery
- payment
- attachments
- confidentiality

پشتیبانی شود.

---

# 27. Offers / Negotiation

State machine:

```text
PENDING
→ COUNTERED
→ ACCEPTED
→ REJECTED
→ EXPIRED
→ CANCELLED
```

هر تغییر:

```text
Audit
Notification
Timestamp
Actor
```

داشته باشد.

---

# 28. Deal Room

DealRoom باید شامل:

```text
Participants
Messages
Offers
Documents
Inspection
Payment
Transport
Audit
```

باشد.

دسترسی باید object-level باشد.

---

# 29. Payment / Finance

Payment مدل وجود دارد.

برای Production باید:

```text
Payment
PaymentAttempt
PaymentEvent
Invoice
Refund
LedgerEntry
```

از هم تفکیک شوند.

## اصل

هیچ Payment status نباید فقط با client تغییر کند.

Gateway callback باید:

```text
signature/verification
idempotency
amount verification
merchant verification
transaction verification
```

داشته باشد.

---

# 30. Upload / Media Security

ماژول magic-byte و size validation موجود است، اما در خود پروژه صراحتاً EXIF sanitization کامل هنوز TODO است.

Pipeline نهایی:

```text
Upload
↓
Authentication
↓
Authorization
↓
Quota
↓
Size
↓
Magic Bytes
↓
Decode
↓
Malware Scan
↓
EXIF Strip
↓
Re-encode
↓
Resize
↓
WebP/AVIF
↓
Object Storage
↓
Metadata
↓
Audit
```

## ممنوع

ذخیره مستقیم فایل خام کاربر در public filesystem در Production.

---

# 31. AI Architecture — اصلاح مهم

در آرشیو، AI Gateway دارای Policy/Quota/Budget است، اما چند Route مستقیم نیز مستقیماً `ZAI.create()` را فراخوانی می‌کنند.

این باعث ایجاد **مسیر موازی خارج از Gateway** می‌شود.

## Routeهای AI مستقیم باید حذف/ادغام شوند

نمونه‌های بررسی‌شده:

```text
/api/ai-listing-builder
/api/ai-price-suggestion
/api/ai-search
/api/ai-seller-assistant
```

و سایر مسیرهای AI باید یا:

```text
Gateway → Task
```

را صدا بزنند یا یک Service داخلی مشترک داشته باشند که همان Policy را enforce کند.

---

# 32. AI Gateway GET Security

`GET /api/ai-gateway` باید Admin-only باشد.

لاگ‌ها و بودجه AI داده حساس عملیاتی هستند و نباید عمومی باشند.

---

# 33. AI Output Validation

JSON تولیدشده توسط AI باید با Zod/Schema validation بررسی شود.

مثلاً:

```text
LLM
→ JSON parse
→ Zod
→ Semantic validation
→ Domain validation
→ Persist only after validation
```

هیچ `JSON.parse` از خروجی LLM نباید به‌تنهایی قابل اعتماد تلقی شود.

---

# 34. AI Prompt Injection

برای داده‌های فروشنده، مقاله، توضیحات و فایل‌ها:

```text
Untrusted Content
```

در نظر گرفته شود.

AI نباید دستور موجود در Listing/Document را به‌عنوان System Instruction اجرا کند.

---

# 35. AI Agent Security

Agentها باید:

```text
Agent
Task
Tools
Permissions
Budget
Scope
ApprovalPolicy
Audit
```

داشته باشند.

Agent نباید Permission عمومی برای DB داشته باشد.

---

# 36. AI Budget

Budget فعلی باید از حالت صرفاً counter به سیستم قابل اتکا ارتقا یابد:

- per-user
- per-role
- per-agent
- per-task
- daily
- monthly
- model
- alert
- hard stop
- fallback
- cost estimate
- actual provider usage

---

# 37. Background Jobs

Queue و jobs در پروژه وجود دارند.

Production باید Queue واقعی داشته باشد:

```text
Redis / Queue
↓
Worker
↓
Retry
↓
Backoff
↓
Dead Letter
↓
Audit
```

کارهای سنگین:

- indexing
- AI
- image processing
- notifications
- cleanup
- analytics
- scraping
- price refresh

نباید request اصلی را block کنند.

---

# 38. Scraper / Data Import

AI scraper نباید منبع Truth شود.

هر داده Imported باید:

```text
source
sourceUrl
sourceType
importedAt
contentHash
confidence
reviewStatus
```

داشته باشد.

Duplicate detection اجباری است.

---

# 39. Data Governance

Canonical entities:

```text
Category
Brand
Model
Generation
Product
Machine
Part
Attachment
Company
Location
```

باید Single Source of Truth باشند.

## Duplicate Policy

قبل از ایجاد:

```text
Exact Match
Alias Match
Normalized Match
Fuzzy Match
AI Candidate
```

بررسی شود.

---

# 40. SEO

SEO باید Entity-driven باشد:

```text
Category
Brand
Model
Product
Machine
Part
Company
Location
Comparison
Knowledge
```

هر Entity:

```text
slug
canonical
title
description
OG
schema.org
sitemap
redirect history
```

داشته باشد.

---

# 41. Knowledge Graph

CompatibilityEdge شروع خوبی است.

Knowledge Graph باید در آینده روابط:

```text
Brand
Model
Product
Machine
Part
Attachment
Application
Industry
Location
Service
Company
```

را پوشش دهد.

AI فقط روی Graph معتبر پاسخ دهد.

---

# 42. Notification

یک Notification Center استاندارد لازم است:

```text
In-App
Email
SMS
Push
Telegram
```

با Preference:

```text
marketing
transactional
security
price alerts
wanted matches
messages
```

---

# 43. Analytics

Event taxonomy رسمی:

```text
SEARCH
VIEW
CLICK
FAVORITE
COMPARE
CONTACT
REQUEST
OFFER
RFQ
QUOTE
PAYMENT
PUBLISH
```

داشته باشد.

Metrics:

```text
DAU/MAU
Search Success
Zero Result Rate
Listing Conversion
Seller Conversion
Request Match Rate
RFQ Conversion
Revenue
AI Cost
```

---

# 44. Observability

Production باید داشته باشد:

```text
Structured Logs
Error Tracking
Metrics
Tracing
Health
Readiness
Liveness
DB Monitoring
Queue Monitoring
AI Monitoring
Security Alerts
```

---

# 45. Backup / Disaster Recovery

حداقل:

```text
Daily backup
Point-in-time recovery
Off-site backup
Restore test
Retention policy
RPO
RTO
```

Backup بدون Restore Test معتبر محسوب نشود.

---

# 46. Testing Master Plan

## Unit

- Persian normalization
- slug
- password
- RBAC
- rate-limit
- upload
- attribute validation
- price calculation
- matching
- state machines

## Integration

- auth
- session
- listing
- catalog
- brand
- company
- RFQ
- offers
- payment
- AI policy
- audit

## E2E

```text
Register
→ Verify
→ Login
→ Create Listing
→ Upload Media
→ Publish
→ Search
→ Compare
→ Offer
→ Deal
```

## Security

- IDOR
- privilege escalation
- CSRF
- XSS
- SQL injection
- upload abuse
- SSRF
- prompt injection
- rate-limit bypass
- session fixation
- replay
- webhook forgery

---

# 47. CI/CD

Pipeline:

```text
Install
↓
Typecheck
↓
Lint
↓
Unit
↓
Integration
↓
Security
↓
Build
↓
Migration Check
↓
Artifact
↓
Deploy
↓
Smoke Test
```

Production deployment باید fail-fast باشد.

---

# 48. Environment Management

Secrets:

```text
DATABASE_URL
ADMIN credentials
SMTP
AI keys
Payment keys
Storage keys
Redis
Sentry
```

نباید hard-code شوند.

`.env` واقعی نباید وارد Git شود.

---

# 49. CORS / CSRF / Headers

Production:

- CSP
- HSTS
- X-Content-Type-Options
- Referrer-Policy
- Permissions-Policy
- frame protection
- secure cookies
- CSRF strategy
- strict origin policy

---

# 50. API Standards

تمام APIها:

```text
Validation
Auth
Authorization
Rate Limit
Error Format
Request ID
Audit
Pagination
Sorting
Filtering
```

را استاندارد کنند.

Response:

```json
{
  "success": true,
  "data": {},
  "meta": {},
  "requestId": "..."
}
```

Error:

```json
{
  "success": false,
  "error": {
    "code": "FORBIDDEN",
    "message": "...",
    "details": {}
  },
  "requestId": "..."
}
```

---

# 51. Pagination

برای داده‌های بزرگ:

```text
cursor pagination
```

ترجیح داده شود.

`offset` فقط برای Admin/داده‌های کوچک.

---

# 52. Admin Command Center

Admin باید یک Control Plane واقعی باشد:

```text
Dashboard
Catalog
Taxonomy
Brands
Models
Products
Machines
Parts
Attachments
Listings
Companies
Users
Verification
Moderation
Requests
RFQ
Offers
Auctions
Deals
Pricing
Search
AI
Jobs
SEO
Knowledge
Payments
Subscriptions
Analytics
Security
Audit
System Health
```

---

# 53. Admin Data Safety

برای عملیات حساس:

```text
Preview
→ Confirmation
→ Reason
→ Execute
→ Audit
```

و برای حذف:

```text
Soft Delete
```

اولویت دارد.

---

# 54. Feature Flags

FeatureFlag موجود است.

باید:

```text
environment
role
percentage rollout
country
company
```

را در صورت نیاز پشتیبانی کند.

---

# 55. Launch Control

LaunchPhase موجود است.

Production باید قابلیت:

```text
maintenance mode
read-only mode
feature freeze
emergency disable
```

داشته باشد.

---

# 56. Performance Budget

برای صفحات اصلی:

- LCP
- CLS
- INP
- JS bundle
- image weight
- API latency

بودجه مشخص شود.

---

# 57. Mobile / PWA

حداقل:

```text
Responsive
PWA
Install
Push
Camera Upload
Share
```

و سپس Native Apps.

---

# 58. Internationalization

ساختار باید از ابتدا:

```text
fa
en
ar
```

را قابل توسعه نگه دارد.

Currency/Unit/Date باید locale-aware باشند.

---

# 59. Store / MEKANIX Separation

در آرشیو یک `store-mekanix-reference` و مسیرهای Store نیز وجود دارد.

این بخش باید از HEAVIX Marketplace Core جدا و به‌عنوان Bounded Context نگهداری شود.

اصل:

```text
HEAVIX
Catalog / Marketplace / Demand

MEKANIX
Service / Maintenance / Repair
```

داده‌های مشترک فقط از طریق Contract/Shared Canonical IDs.

---

# 60. Data Contract بین HEAVIX و MEKANIX

Shared entities:

```text
BrandId
ModelId
ProductId
MachineId
PartId
CompanyId
UserId
```

MEKANIX نباید این داده‌ها را دوباره بسازد.

---

# 61. Price + Compare Integration

دو Feature جدید باید در Core قرار گیرند:

```text
Catalog
   ↓
Listing
   ↓
Pricing Intelligence
   ↓
Compare
   ↓
AI Decision Support
```

Price و Compare نباید سیستم جداگانه‌ای بسازند.

---

# 62. Market Intelligence

بعد از جمع شدن داده:

```text
Supply
Demand
Price
Location
Brand
Model
Season
```

به:

```text
Market Heatmap
Price Trends
Demand Signals
Opportunity Radar
```

تبدیل شود.

این قابلیت‌ها باید descriptive/data-driven باشند و داده خام، زمان و بازار مشخص داشته باشند.

---

# 63. Monetization

Revenue domains:

```text
Subscription
Featured Listing
Promotion
Lead Fee
RFQ Fee
Inspection
Transaction Fee
Advertising
Enterprise
API
```

هر Revenue event باید به Payment/Ledger/Audit متصل باشد.

---

# 64. Definition of Done — Foundation

Foundation زمانی کامل است که:

- [ ] PostgreSQL production contract
- [ ] migration clean
- [ ] seed idempotent
- [ ] Auth secure
- [ ] RBAC enforced
- [ ] Audit complete
- [ ] rate limit
- [ ] upload secure
- [ ] AI gateway unified
- [ ] Product/Machine canonical
- [ ] location canonical
- [ ] transaction canonical
- [ ] tests green
- [ ] build green

---

# 65. Definition of Done — Marketplace

- [ ] Seller
- [ ] Company
- [ ] Listing lifecycle
- [ ] Search
- [ ] Favorites
- [ ] Saved Search
- [ ] Requests
- [ ] Matching
- [ ] Offers
- [ ] RFQ
- [ ] Compare
- [ ] Pricing
- [ ] Messaging
- [ ] Notifications
- [ ] Verification
- [ ] Moderation
- [ ] SEO

---

# 66. Definition of Done — Intelligence

- [ ] AI Gateway
- [ ] AI Listing Builder
- [ ] AI Search
- [ ] AI Compare
- [ ] Price Intelligence
- [ ] Recommendations
- [ ] Demand Engine
- [ ] Knowledge Graph
- [ ] Market Intelligence
- [ ] Opportunity Radar
- [ ] AI Agents
- [ ] AI Audit
- [ ] AI Budget

---

# 67. Definition of Done — Production

هیچ عبارت «Production Ready» نباید قبل از این موارد استفاده شود:

```text
Build = PASS
Lint = PASS
Typecheck = PASS
Unit = PASS
Integration = PASS
E2E = PASS
Security = PASS
Migration = CLEAN
Backup Restore = PASS
Monitoring = ACTIVE
Error Tracking = ACTIVE
Rate Limit = ACTIVE
RBAC = ENFORCED
Audit = ACTIVE
Secrets = SECURE
Payment = VERIFIED
Upload = HARDENED
AI = POLICY CONTROLLED
```

---

# 68. ترتیب اجرایی قطعی

## Phase 0 — Freeze

هیچ Feature غیرضروری اضافه نشود.

## Phase 1 — Stabilize

```text
DB
Migration
Runtime
Build
Typecheck
```

## Phase 2 — Secure

```text
Auth
RBAC
Audit
Rate Limit
Upload
CSRF
Headers
```

## Phase 3 — Canonical Catalog

```text
Taxonomy
Brand
Model
Generation
Product
Machine
Part
Attachment
Compatibility
Attributes
Location
```

## Phase 4 — Marketplace

```text
Seller
Company
Listing
Request
Offer
RFQ
Deal
Messaging
Notification
```

## Phase 5 — Intelligence

```text
Search
Price
Compare
Matching
Recommendation
Demand
Knowledge Graph
```

## Phase 6 — Automation

```text
Jobs
AI Agents
Moderation
Catalog Automation
SEO Automation
Social Automation
```

## Phase 7 — Monetization

```text
Subscription
Featured
Lead
RFQ
Inspection
Transaction
Enterprise
```

## Phase 8 — Scale

```text
PostgreSQL HA
Redis
Search Cluster
Object Storage
CDN
Workers
Observability
DR
```

---

# 69. مواردی که در نسخه فعلی باید فوراً Verify شوند

این موارد در آرشیو به‌صورت صریح نشانه‌های implementation یا TODO دارند و نباید بدون تست «کامل» تلقی شوند:

1. اعمال RBAC روی تمام 101 مسیر Admin.
2. Admin-only بودن GET مربوط به AI Gateway.
3. حذف مسیرهای مستقیم AI خارج از Gateway.
4. اعتبارسنجی ساختاری خروجی LLM.
5. تکمیل EXIF stripping و re-encoding.
6. Malware scanning.
7. canonical Location migration.
8. حذف وابستگی عملی به legacy `User.role`.
9. Object-level authorization برای Listing/Offer/Deal/Document.
10. Payment idempotency و webhook verification.
11. Production Queue.
12. E2E و Security suites.
13. Restore test.
14. PostgreSQL production migration.
15. Build روی محیط Production واقعی.
16. حذف/تفکیک مسیرهای Store/MEKANIX از Marketplace Core.
17. تطبیق تمام APIها با استاندارد response/error.
18. Audit coverage واقعی، نه صرفاً وجود helper.
19. Catalog health و data snapshot.
20. Data quality و duplicate control.

---

# 70. خروجی نهایی مورد انتظار

هدف این سند صرفاً رفع خطا نیست.

Architecture نهایی:

```text
                         HEAVIX
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
     CATALOG           MARKETPLACE       INTELLIGENCE
        │                  │                  │
 Taxonomy/Brand        Listings/RFQ      Search
 Model/Product         Offers/Deals       Pricing
 Machine/Parts         Companies          Compare
 Attributes            Requests           Matching
 Compatibility         Payments           Recommendations
        │                  │                  │
        └──────────────────┼──────────────────┘
                           │
                     CONTROL PLANE
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
       ADMIN            SECURITY             AI
        │                  │                  │
   RBAC/Audit         Auth/RateLimit      Gateway/Agents
   Moderation         Upload              Policy/Budget
   Workflow           Secrets             Automation
                           │
                       PLATFORM
                           │
       PostgreSQL + Redis/Queue + Object Storage
       Search Index + CDN + Observability + Backup
```

---

# 71. قانون نهایی HEAVIX

از این نسخه به بعد:

> **هیچ Feature جدیدی فقط به خاطر جذاب بودن ساخته نشود.**

هر Feature باید این مسیر را طی کند:

```text
Requirement
→ Domain Model
→ Data Contract
→ Security
→ API
→ Service
→ UI
→ Admin
→ Audit
→ Tests
→ Monitoring
→ Documentation
```

و فقط بعد از عبور از این زنجیره:

```text
DONE
```

محسوب شود.

---

# 72. معیار موفقیت نهایی

HEAVIX زمانی به هدف خود نزدیک شده است که:

- کاربر بتواند هر محصول صنعتی را پیدا کند.
- Catalog canonical باشد.
- آگهی با Product اشتباه نشود.
- فروشنده و شرکت قابل اعتماد باشند.
- مشخصات قابل مقایسه باشند.
- قیمت قابل تحلیل باشد.
- درخواست خریدار به فروشنده مناسب Match شود.
- RFQ و Offer قابل مدیریت باشند.
- AI کارهای تکراری را انجام دهد ولی اختیار خطرناک نداشته باشد.
- Admin همه چیز را کنترل کند.
- Security در Server enforce شود.
- داده‌ها provenance داشته باشند.
- سیستم قابل تست، مانیتور و بازیابی باشد.
- و هیچ بخش حیاتی فقط به «کد ظاهراً موجود» وابسته نباشد.

---

# 73. دستور اجرایی

پس از تصویب این سند، توسعه باید از این ترتیب خارج نشود:

```text
P0
↓
Database + Runtime
↓
Security
↓
RBAC
↓
Audit
↓
Canonical Catalog
↓
Marketplace
↓
Search
↓
Pricing
↓
Compare
↓
AI Gateway
↓
Agents
↓
Automation
↓
Monetization
↓
Scale
```

**این سند باید مرجع اجرای تکمیل پروژه باشد؛ اما عبارت «هیچ کم و کاستی» فقط پس از عبور واقعی از Definition of Done، تست امنیتی، E2E، Build، Migration و Production Smoke Test قابل ادعاست.**
